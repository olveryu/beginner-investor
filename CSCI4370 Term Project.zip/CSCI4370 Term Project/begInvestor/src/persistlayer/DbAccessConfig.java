package persistlayer;

public class DbAccessConfig {

	final static String DB_DRIVE_NAME = "com.mysql.jdbc.Driver"; 
		
	final static String DB_CONNECTION_URL = "jdbc:mysql://localhost:3306/stockDB?useSSL=false"; 
		
	final static String DB_CONNECTION_USERNAME = "root";
		
	final static String DB_CONNECTION_PASSWORD = "Weijike5";
		
	
}
